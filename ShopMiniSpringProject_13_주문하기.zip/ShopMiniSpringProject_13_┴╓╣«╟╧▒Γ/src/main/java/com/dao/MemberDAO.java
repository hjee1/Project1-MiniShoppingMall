package com.dao;

import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.MemberDTO;

@Repository
public class MemberDAO {

	@Autowired
	SqlSessionTemplate template;

	public int memberAdd(MemberDTO dto) {
		return template.insert("MemberMapper.memberAdd", dto);
	}

	public MemberDTO login(Map<String, String> map) {
		return template.selectOne("MemberMapper.login", map);
	}

	public MemberDTO mypage(String userid) {
		return template.selectOne("MemberMapper.mypage", userid);
	}

	public void memberUpdate(MemberDTO m) {
		template.update("MemberMapper.memberUpdate", m);
	}

}
