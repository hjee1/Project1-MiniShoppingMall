package com.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.dto.CartDTO;
import com.dto.GoodsDTO;
import com.dto.MemberDTO;
import com.service.GoodsService;
import com.service.MemberService;

@Controller
public class GoodsController {
	@Autowired
	GoodsService service;

	@Autowired
	MemberService mService;

	@RequestMapping("/goodsRetrieve")
	@ModelAttribute("goodsRetrieve") // key값
	public GoodsDTO goodsRetrieve(@RequestParam("gCode") String gCode) {
		GoodsDTO dto = service.goodsRetrieve(gCode);
		return dto;
	}

	@RequestMapping("/goodsList")
	public ModelAndView goodsList(@RequestParam("gCategory") String gCategory) {// 카테고리별 상품목록보기 단 로그인 된 경우만 호출
		if (gCategory == null) {
			gCategory = "top";
		}
		List<GoodsDTO> list = service.goodsList(gCategory);
		ModelAndView mav = new ModelAndView();
		mav.addObject("goodsList", list); //
		// request.setAttribute("goodsList", list)와 동일
		mav.setViewName("main"); // main.jsp=> goodList.jsp에서 목록을 뿌려줌
		return mav;
	}

	@RequestMapping("/loginCheck/cartAdd")
	public String cartAdd(CartDTO cdto, HttpSession session) {
		MemberDTO mdto = (MemberDTO) session.getAttribute("login");
		String userid = mdto.getUserid();
		// System.out.println(userid);
		cdto.setUserid(userid);
		// System.out.println(cdto);
		session.setAttribute("mesg", cdto.getgCode());
		int n = service.cartAdd(cdto);
		// System.out.println(n);
		return "redirect:../goodsRetrieve?gCode=" + cdto.getgCode();
	}

	@RequestMapping("/loginCheck/CartList")
	public String cartList(HttpSession session, RedirectAttributes attr) {
		MemberDTO mdto = (MemberDTO) session.getAttribute("login");
		String userid = mdto.getUserid();
		List<CartDTO> list = service.cartList(userid);
		// System.out.println(list);
		attr.addFlashAttribute("cartList", list);
		return "redirect:../cartList";
	}

	@RequestMapping("/loginCheck/cartUpdate")
	@ResponseBody
	public void cartUpdate(@RequestParam Map<String, String> map) {
		// System.out.println(map);
		service.cartUpdate(map);
	}

	@RequestMapping("loginCheck/cartDelete")
	@ResponseBody
	public void cartDelete(@RequestParam("num") int num) {
		// System.out.println(num);
		int n = service.cartDelete(num);
		System.out.println(n);
	}

	@RequestMapping(value = "/loginCheck/delAllCart")
	public String delAllCart(@RequestParam("check") ArrayList<String> list) {
		// System.out.println(list);
		service.delAllCart(list);
		return "redirect:../cartList";
	}

	@RequestMapping("/loginCheck/orderConfirm")
	public String orderConfirm(@RequestParam("num") int num, HttpSession session, RedirectAttributes xxx) {
		MemberDTO mdto = (MemberDTO) session.getAttribute("login");
		String userid = mdto.getUserid();
		mdto = mService.mypage(userid);
		CartDTO cdto = service.orderConfirmByNum(num);
		//System.out.println(cdto);
		xxx.addFlashAttribute("mdto", mdto);
		xxx.addFlashAttribute("cdto", cdto);
		return "redirect:../orderConfirm";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
