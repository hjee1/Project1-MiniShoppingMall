package com.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dto.MemberDTO;
import com.service.MemberService;

@Controller
public class MemberController {
	@Autowired
	MemberService service;

	@RequestMapping(value = "/memberAdd")
	public String memberAdd(MemberDTO dto, Model model) {
		service.memberAdd(dto);
		model.addAttribute("success", "회원가입성공");
		return "main";
	}
	
	@RequestMapping(value = "/loginCheck/mypage")
	public String mypage(HttpSession session) {
		MemberDTO dto = (MemberDTO) session.getAttribute("login");
		String userid = dto.getUserid();
		dto = service.mypage(userid);
		//System.out.println(dto);
		session.setAttribute("login", dto);
		return "redirect:../mypage";
	}
	
	@RequestMapping(value = "/idDuplicateCheck", produces = "text/plain;charset=UTF-8")//한글처리
	public @ResponseBody String idDuplicateCheck(@RequestParam("id") String userid) {
		MemberDTO dto = service.mypage(userid);
		String mesg = "";
		//System.out.println(dto);
		if(dto != null) {
			mesg = "아이디 사용가능";
		}else {
			mesg = "아이디 중복";
		}
		return mesg;
	}
	
	@RequestMapping(value = "/loginCheck/memberUpdate")
	public String memberUpdate(MemberDTO m) {//회원정보수정
		//System.out.println("memberUpdate====="+ m);
		service.memberUpdate(m);
		return "redirect:../loignCheck/myPage";
	}

}
